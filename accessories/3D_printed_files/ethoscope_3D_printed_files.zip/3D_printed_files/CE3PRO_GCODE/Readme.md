GCODE files for Creality Ender 3 Pro, sliced with Ultimaker CURA using Low Quality settings (0.28mm) and brim. 
All print with no support.
